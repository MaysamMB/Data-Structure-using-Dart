// import 'dart:io';

class Stack<E> {
  Stack() : _storage = <E>[];
  final List<E> _storage;

// Challenge 1:
  // ********************** reverse List ******************************** //
  void reverseList<E>(List<E> list) {
    print("reversed List : ");
    final stack = Stack<E>();
    for (final item in list) {
      stack.push(item);
    }
    List<E> result = [];
    while (stack.isNotEmpty) {
      result.add(stack.pop());
    }
    print(result);
  }
  // ************************************************** //

// Challenge 2:
  // ******************** Parentheses Balanced  ************************** //
  bool isParenthesesBalanced(String str) {
    final stack = Stack<String>();

    for (final char in str.split('')) {
      if (char == '(') {
        stack.push(char);
      } else if (char == ')') {
        if (stack.isEmpty) return false;
        stack.pop();
      }
    }

    return stack.isEmpty;
  }
  // ************************************************** //

  void push(E element) => _storage.add(element);

  E pop() => _storage.removeLast();

  E get peek => _storage.last;

  bool get isEmpty => _storage.isEmpty;

  bool get isNotEmpty => !isEmpty;

  Stack.of(Iterable<E> elements) : _storage = List<E>.of(elements);

  @override
  String toString() {
    return '--- Top ---\n'
        '${_storage.reversed.join('\n')}'
        '\n-----------';
  }
}

void main() {
  // Challenge 1:
  // ********************** reverse List ******************************** //
  const list = ['S', 'M', 'O', 'K', 'E'];
  final smokeStack = Stack.of(list);
  smokeStack.reverseList(list);
  // ************************************************** //

// Challenge 2:
  // ******************** Parentheses Balanced  ************************** //

  String str = "h((e))llo(world)()";
  String str2 = "(hello world";
  final parenthesesBalanced = Stack();

  if (parenthesesBalanced.isParenthesesBalanced(str)) {
    print("Parentheses is Balanced");
  } else {
    print("Parentheses is not Balanced");
  }

  print(parenthesesBalanced.isParenthesesBalanced(str2));

  // ************************************************** //

  // ********************* Stack ***************************** //

  // final stack = Stack<int>();
  // stack.push(1);
  // stack.push(2);
  // stack.push(3);
  // stack.push(4);
  // print(stack);

  // ********************** Remove From Stack **************************** //

  // final element = stack.pop();
  // print('Popped: $element');
  // print(smokeStack);
  // smokeStack.pop();
}
