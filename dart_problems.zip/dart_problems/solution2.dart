import 'solution.dart';

class Node<T> {
  Node({required this.value, this.next});
  T value;
  Node<T>? next;

  @override
  String toString() {
    if (next == null) return '$value';
    return '$value -> ${next.toString()}';
  }
}

class LinkedList<E> {
  Node<E>? head;
  Node<E>? tail;

// Challenge 1:
  // ********************** Print in Reverse **************************** //

  void printInReverse<T>(Node<T>? node) {
    final stack = Stack<T>();

    while (node != null) {
      stack.push(node.value);
      node = node.next;
    }

    while (!stack.isEmpty) {
      print(stack.pop());
    }
  }

// Challenge 2:
  // ********************** Middle node **************************** //

  Node<E>? findMiddleNode<E>(Node<E>? head) {
    var slowPointer = head;
    var fast = head;

    while (fast != null && fast.next != null) {
      slowPointer = slowPointer!.next;
      fast = fast.next!.next;
    }

    return slowPointer;
  }
  // ************************************************** //

// Challenge 3:
  // ********************** Reverse List **************************** //

  void reverse() {
    Node<E>? previous = null;
    Node<E>? current = head;
    Node<E>? next;

    while (current != null) {
      next = current.next;
      current.next = previous;

      previous = current;
      current = next;
    }
    head = previous;
  }
  // ************************************************** //

// Challenge 4:
  // ********************** Remove All Occurrences **************************** //

  void removeAllOccurrences(E value) {
    while (head != null && head!.value == value) {
      head = head!.next;
    }

    if (head == null) return;

    var currentNode = head;
    while (currentNode?.next != null) {
      if (currentNode!.next!.value == value) {
        currentNode.next = currentNode.next!.next;
      } else {
        currentNode = currentNode.next;
      }
    }

    if (tail?.value == value) {
      tail = currentNode;
    }
  }
  // ************************************************** //

  bool get isEmpty => head == null;

  void push(E value) {
    head = Node(value: value, next: head);
    tail ??= head;
  }

  void append(E value) {
    if (isEmpty) {
      push(value);
      return;
    }
    tail!.next = Node(value: value);
    tail = tail!.next;
  }

  Node<E>? nodeAt(int index) {
    var currentNode = head;
    var currentIndex = 0;

    while (currentNode != null && currentIndex < index) {
      currentNode = currentNode.next;
      currentIndex += 1;
    }
    return currentNode;
  }

  Node<E> insertAfter(Node<E> node, E value) {
    if (tail == node) {
      append(value);
      return tail!;
    }

    node.next = Node(value: value, next: node.next);
    return node.next!;
  }

  E? pop() {
    final value = head?.value;
    head = head?.next;
    if (isEmpty) {
      tail = null;
    }
    return value;
  }

  E? removeLast() {
    if (head?.next == null) return pop();

    var current = head;
    while (current!.next != tail) {
      current = current.next;
    }

    final value = tail?.value;
    tail = current;
    tail?.next = null;
    return value;
  }

  E? removeAfter(Node<E> node) {
    final value = node.next?.value;
    if (node.next == tail) {
      tail = node;
    }
    node.next = node.next?.next;
    return value;
  }

  @override
  String toString() {
    if (isEmpty) return 'Empty list';
    return head.toString();
  }
}

void main() {
  // ********************** Node **************************** //

  final node1 = Node(value: 1);
  final node2 = Node(value: 2);
  final node3 = Node(value: 3);

  node1.next = node2;
  node2.next = node3;

  // print(node1);

  // ********************** Linked List **************************** //

  final list = LinkedList<int>();
  // Push front
  list.push(3);
  list.push(2);
  list.push(1);
  list.push(0);
  print('the list: $list');
  print("******************************************");

// Challenge 1:
  // ********************** Print in Reverse **************************** //

  print("Print in Reverse: ");
  list.printInReverse(list.head);
  // print('the list: $list');
  print("******************************************");

// Challenge 2:
  // ********************** Middle node **************************** //

  print('The middle node is: ');
  final mid = list.findMiddleNode(list.head);
  print(mid?.value);
  print("******************************************");

// Challenge 3:
  // ********************** Reverse List **************************** //
  list.reverse();
  print('The list after reverse: ');
  print(list);
  print("******************************************");
  list.push(2);
  print("new list: $list");
  print("******************************************");
// Challenge 4:
  // ********************** Remove All Occurrences **************************** //
  print("After remove all occurrences of 2: ");
  list.removeAllOccurrences(2);
  print(list);
  print("******************************************");

// other function:
  // append
  // final list2 = LinkedList<int>();
  // list2.append(1);
  // list2.append(2);
  // list2.append(3);

  // print(list2);
  // print("******************************************");

  // insert after
  // print('Before: $list');

  // var middleNode = list.nodeAt(1)!;
  // list.insertAfter(middleNode, 42);

  // print('After:  $list');
  // print("******************************************");

  // remove top
  // final poppedValue = list.pop();

  // print('After remove top:  $list');
  // print('Popped value: $poppedValue');
  // print("******************************************");

  // remove last
  // final removedValue = list.removeLast();

  // print('After:  $list');
  // print('Removed value: $removedValue');
  // print("******************************************");

  // remove from middle

  // final firstNode = list.nodeAt(0);
  // final removedValue1 = list.removeAfter(firstNode!);

  // print('After:  $list');
  // print('Removed value: $removedValue1');
  // print("******************************************");
}
